/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function validateForm() {
    var ip1= document.forms["myForm"]["xyzname"].value;
    if ( ip1 == null || ip1 == "") {
        alert("Please enter your name");
        return false;
    }
    var ip2 = document.forms["myForm"]["xyzemail"].value;
    var atpos = ip2.indexOf("@");
    var dotpos = ip2.lastIndexOf(".");
    if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=ip2.length) {
        alert("Please enter a valid e-mail address");
        return false;
    }
}
